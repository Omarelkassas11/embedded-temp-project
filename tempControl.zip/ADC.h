// Function prototypes defined in header file for the ADC library
// .h files should be included in main app in order to use the library

void ADC_Init();
int ADC_Read(int channel);
